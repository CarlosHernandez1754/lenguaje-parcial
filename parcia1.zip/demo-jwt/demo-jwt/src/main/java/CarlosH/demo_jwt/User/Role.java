
package CarlosH.demo_jwt.User;


public enum Role {
    ADMIN,
    USER  
}
